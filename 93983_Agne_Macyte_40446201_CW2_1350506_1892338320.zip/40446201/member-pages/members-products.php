<?php
session_start();

if (!isset($_SESSION['username2'])) {
	header("location: index.html");
    die();
}
?>

<!DOCTYPE HTML>
<html lang="en">
    <head>
        <meta charset="utf-8" name="description" content="The website is an online shop for alcoholic drinks that will be delivered to your door within 1 hour" name="keywords" content="Drinks, delivery, fast-delivery, alcohol-delivery, alcohol, Edinburgh">
        <title>Cheers! Products </title>
        <link href="../styles.css" type="text/css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Alice&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/16a97854c0.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <header>
             <nav class="navigation">
				<div class ="logo_div">
				<img src="../Images/logo.png" alt="This is a logo" class="logo">
				</div>
                <div class="navbar-links">
					<ul>
						<div class="nav">
						<li class="nav"><a href="members-only.php">HOME</a></li>
						<li class="nav"><a href="members-about.php"> ABOUT </a></li>
						<div class="dropdown">
						  <button class="dropbtn"><a href="members-products.html">PRODUCTS</a><i class="fas fa-caret-down"></i></button>
						  <div class="dropdown-content">
							<a href="members-products.php">Spirits</a>
							<a href="members-products.php#wines">Wines</a>
							<a href="members-products.php#beers">Beers</a>
							<a href="members-products.php#non-alcoholic">Soft Drinks</a>
							<a href="members-products.php">All</a>
						  </div>
						</div>
						<li class="nav"><a href="members-contact.php">CONTACT</a></li>
						</div>
						<div class="nav-buttons">
							<li><a href="profile.php"><i class="fas fa-user"></i></a></li>
							<li><a href="members-order.php"><i class="fas fa-shopping-cart"></i></a></li>
							<li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i></a></li>
						</div>
					</ul>
				</div>
            </nav>
        </header>
		<main>
			<section class="products">
				<div class="products-heading">
					<h1>DISCOVER OUR FINEST DRINKS! &nbsp; &nbsp; &nbsp; 1 HOUR DELIVERY TO YOUR DOOR</h1>
				</div>
				<div class="spirits">
					<h2>SPIRITS:</h2>
					<table class="spirits">
						<tr>
							<td><img src="../Images/spirits/gordons.png"> 
							<td><img src="../Images/spirits/tanqueray.png"></td>
							<td><img src="../Images/spirits/vodka.png"></td>
							<td><img src="../Images/spirits/vodka1.png"></td>
							<td><img src="../Images/spirits/vodka2.png"></td>
						</tr>
							<tr>
							<td>Gordons Gin 1l</td>
							<td>Tanqueray Gin 0,7l</td>
							<td>Russian Standard Vodka 1l</td>
							<td>Absolut Vodka 0,7l</td>
							<td>Tito's Vodka 1l</td>
						</tr>
						<tr>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							
						</tr>
						<tr>
							<td><img src="../Images/spirits/rum1.png"></td>
							<td><img src="../Images/spirits/rum2.png"></td>
							<td><img src="../Images/spirits/rum3.png"></td>
							<td><img src="../Images/spirits/whisky1.png"></td>
							<td><img src="../Images/spirits/tequila.png"></td>
						</tr>
							<tr>
							<td>Mount Gay Rum 1l</td>
							<td>Captain Morgan Rum 0,7l</td>
							<td>Bacardi Rum 0,7l</td>
							<td>Jack Daniel's Whisky 1l</td>
							<td id="wines">Jose Cuervo Tequila 1l</td>
						</tr>
						<tr>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
						</tr>
					</table>
				</div>
				<div class="wines">
					<h2>WINES:</h2>
					<table class="wines">
						<tr>
							<td><img src="../Images/wines/white1.png"></td>
							<td><img src="../Images/wines/white2.png"></td>
							<td><img src="../Images/wines/white3.png"></td>
							<td><img src="../Images/wines/rose2.png"></td>
							<td><img src="../Images/wines/rose3.png"></td>
						</tr>
							<tr>
							<td>Burlesque Chardonnay 1l</td>
							<td>The Cloud Sauvingnon Blanc 1l</td>
							<td>Nirabell Pinot Grigio 1l</td>
							<td>Nirabell Rose 1l</td>
							<td>Ancora Rose 1l</td>
						</tr>
						<tr>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
						</tr>
						<tr>
							<td><img src="../Images/wines/red1.png"></td>
							<td><img src="../Images/wines/red2.png"></td>
							<td><img src="../Images/wines/red3.png"></td>
							<td><img src="../Images/wines/prosecco1.png"></td>
							<td><img src="../Images/wines/prosecco2.png"></td>
						</tr>
							<tr>
							<td>Cape Heights Malbec 1 l</td>
							<td>Staton Merlot 1l</td>
							<td>The Cloud Pinot Noir 1l</td>
							<td>Coller Prosecco 1l</td>
							<td id="beers">Moet Champagne 1l</td>
						</tr>
						<tr>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
						</tr>
					</table>
				</div>
				<div class="beers">
					<h2>BEERS:</h2>
					<table class="beers">
						<tr>
							<td><img src="../Images/beer/beer1.png"></td>
							<td><img src="../Images/beer/beer.png"></td>
							<td><img src="../Images/beer/beer2.png"></td>
							<td><img src="../Images/beer/beer3.png"></td>
						</tr>
							<tr>
							<td>Corona 4 Pack</td>
							<td>Stella Artois 6 Pack</td>
							<td>Peroni 4 Pack</td>
							<td>Brewdog Pink IPA 0,3l</td>
						</tr>
						<tr>
							<td><a href="../members-order.php"><p>BUY</p></a></td>
							<td><a href="../members-order.php"><p>BUY</p></a></td>
							<td><a href="../members-order.php"><p>BUY</p></a></td>
							<td><a href="../members-order.php"><p>BUY</p></a></td>
						</tr>
					</table>
				</div>
				<div class="non-alcoholic" id="non-alcoholic">
					<h2>SOFT DRINKS:</h2>
					<table>
						<tr>
							<td><img src="../Images/non_alcohol/cola.png"></td>
							<td><img src="../Images/non_alcohol/dietcoke.png"></td>
							<td><img src="../Images/non_alcohol/slimline.png"></td>
							<td><img src="../Images/non_alcohol/tonic.png"></td>
							<td><img src="../Images/non_alcohol/sprite.png"></td>
						</tr>
						<tr>
							<td>Coca Cola 1 l</td>
							<td>Diet Coke 1l</td>
							<td>Tonic Water 1l</td>
							<td>Slimline Tonic 1l</td>
							<td>Sprite 1l</td>
						</tr>
						<tr>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
							<td><a href="members-order.php"><p>BUY</p></a></td>
						</tr>
					</table>
				</div>
			</section>		
		</main>
			<footer>
			<section class="footer">
				<table>
					<tr>
						<td>Copyright by<br>Agne Macyte<br>2019</td>
						<td><a href="members-contact.php">Contact Us</a></td>
						<td>
						<div class="socials">
							<a href="#"><i class="fab fa-facebook-square"></i></a>
							<a href="#"><i class="fab fa-instagram"></i></a>
							<a hred="#"><i class="fab fa-twitter-square"></i></a>	
					</div>
						</td>
					</tr>
				</table>
			</section>
		</footer>
    </body>
</html>
   